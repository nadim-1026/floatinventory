from django.urls import path

from . import views
from .views import get_piston_data,get_valve_set_data, get_all_valve_set_data, get_valve_piece_data,create_valve_set,update_piston
urlpatterns = [
    path('create_valve_set/', create_valve_set,name='create_valve_set'),
   # path('/text',text),
    path('', views.index, name='index'),
    # path('api/v1/valvesets/', ValveSetListCreateView.as_view(), name='valveset-list-create'),
    # path('api/v1/pistons/<int:pk>/', PistonRetrieveUpdateView.as_view(), name='piston-retrieve-update'),
    # path('api/v1/valve-pieces/<int:pk>/', ValvePieceRetrieveUpdateView.as_view(), name='valvepiece-retrieve-update'),

    #path('api/v1/valve-pieces/<str:valve_piece_id>/', get_valve_piece),
    #path('api/v1/valve-pieces/', update_valve_piece),
    #path('api/v1/valvesetquantity/', update_valve_set_quantity),
    #path('api/v1/get-pistons/<str:piston_id>/', get_piston),
    path('get_all_valve_set_data/', get_all_valve_set_data,name='get_all_valve_set_data'),
    path('get_valve_set_data/<str:id>', get_valve_set_data,name='get_valve_set_data'),
    path('get_piston_data/<str:id>', get_piston_data,name='get_piston_data'),
    path('get_valve_piece_data/<str:id>', get_valve_piece_data,name='get_valve_piece_data'),

    path('update-piston/', update_piston),
    # Add more URL patterns for other views as needed...
]
