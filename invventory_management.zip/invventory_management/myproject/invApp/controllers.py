# controllers.py
from .models import ValveSet, Piston, ValvePiece
from rest_framework.response import Response
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
from rest_framework.decorators import api_view

@api_view(['GET'])
def get_all_valve_sets(request):
    valve_sets = ValveSet.objects.all()
    print("nadim")
    serializer = ValveSetSerializer(valve_sets, many=True)

    return Response(serializer.data)


def get_all_pistons():
    pistons=Piston.objects.all()
    print("chetan")
    serializer = PistonSerializer(pistons, many=True)
    return Response(serializer.data)
def get_all_valve_piece():
    valve_pieces=ValvePiece.objects.all()
    serializer = ValvePieceSerializer(valve_pieces, many=True)
    return Response(serializer.data)
# Add similar functions for other controllers...

def update_valve_set_quantity(valve_set_data):
    # Add logic to update valve set quantity
    return {'success': True}
