
from django.shortcuts import render, redirect
#from .models import ValveSet, Piston, ValvePiece, ValveSetQuantity, PistonQuantity, ValvePieceQuantity
from .forms import ValveSetQuantityForm, PistonForm, ValvePieceForm,ValveSetForm
from django.contrib import messages
# views.py
from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
#from .models import ValveSet, Piston, ValvePiece, ValveSetQuantity, PistonQuantity, ValvePieceQuantity
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
from rest_framework import generics
from .models import ValveSet, Piston, ValvePiece
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
# views.py
from rest_framework.decorators import api_view
import json
from rest_framework.response import Response
from .models import ValveSet, Piston, ValvePiece,ValveSetQuantity
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer,ValveSetQuantitySerializer
from rest_framework import status





'''@api_view(['PUT'])
def update_piston(request):
    piston_id = request.data.get('piston_id')

    try:
        piston = Piston.objects.get(pk=piston_id)
    except Piston.DoesNotExist:
        return Response({'error': 'Piston not found'}, status=status.HTTP_404_NOT_FOUND)

    # Assuming request.data contains the updated data for the piston
    serializer = PistonSerializer(piston, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()
        return Response({'success': True})
    else:
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_valve_piece(request, valve_piece_id):
    valve_piece = ValvePiece.objects.get(pk=valve_piece_id)
    serializer = ValvePieceSerializer(valve_piece)
    return Response(serializer.data)

@api_view(['PUT'])
def update_valve_piece(request):
    valve_piece_id = request.data.get('valve_piece_id')

    try:
        valve_piece = ValvePiece.objects.get(pk=valve_piece_id)
    except ValvePiece.DoesNotExist:
        return Response({'error': 'ValvePiece not found'}, status=status.HTTP_404_NOT_FOUND)

    # Assuming request.data contains the updated data for the valve piece
    serializer = ValvePieceSerializer(valve_piece, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()
        return Response({'success': True})
    else:
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET'])
def get_all_valve_sets(request):
    valve_sets = ValveSet.objects.all()
    print(valve_sets)
    serializer = ValveSetSerializer(valve_sets, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def get_piston(request):
    print("chetan")
    pistons=Piston.objects.all()
    serializer = PistonSerializer(pistons, many=True)
    return serializer.data


from rest_framework import status

@api_view(['PUT'])
def update_valve_set_quantity(request):
    valve_set_id = request.data.get('valve_set_id')

    try:
        valve_set_quantity = ValveSetQuantity.objects.get(pk=valve_set_id)
    except ValveSetQuantity.DoesNotExist:
        return Response({'error': 'ValveSetQuantity not found'}, status=status.HTTP_404_NOT_FOUND)

    # Assuming request.data contains the updated data for the valve set quantity
    serializer = ValveSetQuantitySerializer(valve_set_quantity, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()
        return Response({'success': True})
    else:
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)'''


# class ValveSetListCreateView(generics.ListCreateAPIView):
#     queryset = ValveSet.objects.all()
#     serializer_class = ValveSetSerializer
#
#
# class PistonRetrieveUpdateView(generics.RetrieveUpdateAPIView):
#     queryset = Piston.objects.all()
#     print(queryset)
#     serializer_class = PistonSerializer
#
#
# class ValvePieceRetrieveUpdateView(generics.RetrieveUpdateAPIView):
#     queryset = ValvePiece.objects.all()
#     serializer_class = ValvePieceSerializer

#
# def index(request):
#     valve_sets = ValveSet.objects.all()
#     pistons = Piston.objects.all()
#     valve_pieces = ValvePiece.objects.all()
#
#     if request.method == 'POST':
#         valve_set_form=ValveSetForm(request.POST)
#         valve_set_quantity_form = ValveSetQuantityForm(request.POST)
#         piston_quantity_form = PistonForm(request.POST)
#         valve_piece_quantity_form = ValvePieceForm(request.POST)
#
#         forms = {
#             'valve_set_form':valve_set_form,
#             'valve_set_quantity_form': valve_set_quantity_form,
#             'piston_quantity_form': piston_quantity_form,
#             'valve_piece_quantity_form': valve_piece_quantity_form,
#         }
#
#         if all(form.is_valid() for form in forms.values()):
#             valve_set_form.save()
#             valve_set_quantity_form.save()
#             piston_quantity_form.save()
#             valve_piece_quantity_form.save()
#             # Add success message or redirection logic here
#
#         else:
#             # Handle errors for each form
#             for form_name, form in forms.items():
#                 if not form.is_valid():
#                     # You can add custom error messages or log errors here
#                     print(f"{form_name} has errors:", form.errors)
#
#                     # Update the context to include the form with errors
#                     context = {
#                         'valve_sets': valve_sets,
#                         'pistons': pistons,
#                         'valve_pieces': valve_pieces,
#                         'valve_set_quantity_form': forms['valve_set_quantity_form'],
#
#                     }
#
#                     # Render the template with the updated context
#                     print(valve_sets)
#                     return render(request, 'index.html', context)
#     else:
#         valve_set_quantity_form = ValveSetQuantityForm()
#         piston_quantity_form = PistonForm()
#         valve_piece_quantity_form = ValvePieceForm()
#
#     context = {
#         'valve_sets': valve_sets,
#         'pistons': pistons,
#         'valve_pieces': valve_pieces,
#         'valve_set_quantity_form': valve_set_quantity_form,
#         'piston_quantity_form': piston_quantity_form,
#         'valve_piece_quantity_form': valve_piece_quantity_form,
#     }
#
#     return render(request, 'index.html', context)
#
#
# from django.shortcuts import render
#
# # Create your views here.
#
# # get -> data fetch
# # put => data update
# # post -> new data create
# # delete -> data delete
# # MyApp/views.py
# def create_piston(request):
#     if request.method == 'POST':
#         form = PistonForm(request.POST)
#         if form.is_valid():
#             form.save()
#             # Add a success message or redirect to another page
#     else:
#         form = PistonForm()
#
#     return render(request, 'piston_form.html', {'form': form})


from django.shortcuts import render
from .models import ValveSet, Piston, ValveSetQuantity, ValvePiece
from .forms import ValveSetForm, PistonForm, ValveSetQuantityForm, ValvePieceForm


def index(request):
    return render(request, 'index.html')

def text(request):
    return render(request,'text.html')
def create_valve_set(request):
    message = None

    if request.method == 'POST':

        piston_form = PistonForm(request.POST)
        valve_piece_form = ValvePieceForm(request.POST)

        if piston_form.is_valid() and valve_piece_form.is_valid():

            piston = piston_form.save(commit=False)
            valve_piece = valve_piece_form.save(commit=False)

            # Save Piston subtypes
            for i in range(1, 16):
                subtype_key = f'piston_subtype_{i}'
                setattr(piston, subtype_key, piston_form.cleaned_data.get(subtype_key, 0))

            piston.save()

            # Save ValvePiece subtypes
            for i in range(1, 16):
                subtype_key = f'valve_piece_subtype_{i}'
                setattr(valve_piece, subtype_key, valve_piece_form.cleaned_data.get(subtype_key, 0))

            valve_piece.save()

            message = 'Data has been successfully stored.'

    else:

        piston_form = PistonForm()
        valve_piece_form = ValvePieceForm()

    return render(request, 'text.html', {

        'piston_form': piston_form,
        'valve_piece_form': valve_piece_form,
        'message': message,
    })


from django.shortcuts import render
from .models import ValvePiece

from django.shortcuts import render
from .models import ValvePiece

from django.shortcuts import render
from .models import ValvePiece, Piston


# def stacked_bar_graph(request):
#     # Fetch the fifth row from ValvePiece
#     valve_piece_data = ValvePiece.objects.all().order_by('valve_piece_id')[3:4].first()
#
#     # Fetch the fifth row from Piston
#     piston_data = Piston.objects.all().order_by('piston_id').first()
#
#     if not valve_piece_data or not piston_data:
#         # Handle the case where the specified row is not found
#         return render(request, 'index.html', {'error_message': 'Fifth row not found'})
#
#     # Prepare data for ValvePiece
#     valve_subtype_names = [f'valve_piece_subtype_{i}' for i in range(1, 16)]
#     valve_data_values = [valve_piece_data.__dict__[subtype] for subtype in valve_subtype_names]
#
#     # Prepare data for Piston
#     piston_subtype_names = [f'piston_subtype_{i}' for i in range(1, 16)]
#     piston_data_values = [piston_data.__dict__[subtype] for subtype in piston_subtype_names]
#
#     return render(request, 'index.html', {
#         'valve_subtype_names': valve_subtype_names,
#         'valve_data_values': [valve_data_values],
#         'piston_subtype_names': piston_subtype_names,
#         'piston_data_values': [piston_data_values]
#     })


from django.http import JsonResponse
from .models import Piston, ValvePiece, ValveSet
from .serializers import ValveSetSerializer

@api_view(['PATCH', 'PUT'])
def update_piston(request):
    body = json.loads(request.body.decode('utf-8'))

    #
    #  piston=''
    #
    # # Save Piston subtypes
    # for i in range(1, 16):
    #     subtype_key = f'piston_subtype_{i}'
    #     setattr(piston, subtype_key,body[subtype_key])
    #
    # piston.save()



    if True:
        return JsonResponse({
            "success": True,
            "body" : body
        }, safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})


def get_all_valve_set_data(request):
    valve_sets = ValveSet.objects.all()
    print("All Valve Sets: ", valve_sets)
    data = ValveSetSerializer(valve_sets, many=True);


    if valve_sets:
        return JsonResponse(data.data, safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})



def get_valve_set_data(request, id):
    valve_sets = ValveSet.objects.filter(valve_set_id=id).values()
    print(valve_sets)

    if valve_sets:
        return JsonResponse(list(valve_sets)[0], safe=False)
    else:
        return JsonResponse({'error': 'No Valve Sets data found'})




def get_piston_data(request, id):

    piston_data = Piston.objects.filter(piston_id=id).values()
    print(piston_data)
    if piston_data:
        return JsonResponse(list(piston_data)[0], safe=False)
    else:
        return JsonResponse({'error': 'No Piston data found'})

def get_valve_piece_data(request, id):

    valve_piece_data = ValvePiece.objects.filter(valve_piece_id=id).values()
    print(valve_piece_data)
    if valve_piece_data:
        return JsonResponse(list(valve_piece_data)[0], safe=False)
    else:
        return JsonResponse({'error': 'No ValvePiece data found'})



def get_all_valve_piece_data(request):
    valve_piece_data = ValvePiece.objects.order_by('valve_piece_id')[1:2].first()  # You might need to adjust this logic
    if valve_piece_data:
        data = {
            'valve_piece_id': valve_piece_data.valve_piece_id,
            **{f'valve_piece_subtype_{i}': getattr(valve_piece_data, f'valve_piece_subtype_{i}') for i in range(1, 16)}
        }
        return JsonResponse(data)
    else:
        return JsonResponse({'error': 'No ValvePiece data found'})












































def get_piston_ids(request):
    piston_ids = Piston.objects.values_list('piston_id', flat=True)
    return JsonResponse({'piston_ids': list(piston_ids)})


def get_valve_piece_ids(request):
    valve_piece_ids = ValvePiece.objects.values_list('valve_piece_id', flat=True)
    return JsonResponse({'valve_piece_ids': list(valve_piece_ids)})