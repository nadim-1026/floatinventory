# serializers.py
from rest_framework import serializers
from .models import ValveSet, Piston, ValvePiece,ValveSetQuantity

class ValveSetSerializer(serializers.ModelSerializer):
    class Meta:
        model = ValveSet
        fields = '__all__'

class PistonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Piston
        fields = '__all__'

class ValvePieceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ValvePiece
        fields = '__all__'
class ValveSetQuantitySerializer(serializers.ModelSerializer):
    class Meta:
        model = ValveSetQuantity
        fields = '__all__'
