views.py
from django.shortcuts import render, redirect
from .forms import PistonForm, ValvePieceForm
from .models import Piston, ValvePiece

def create_valve_piece(request):
    valve_piece_form = ValvePieceForm()

    if request.method == 'POST':
        valve_piece_form = ValvePieceForm(request.POST)

        if valve_piece_form.is_valid():
            # Save the form data to create a new ValvePiece instance
            valve_piece = valve_piece_form.save()
            # Add a success message or redirect to another page

    return render(request, 'valve_piece_form.html', {'valve_piece_form': valve_piece_form})

def create_piston(request):
    if request.method == 'POST':
        form = PistonForm(request.POST)
        if form.is_valid():
            form.save()
            # Add a success message or redirect to another page
    else:
        form = PistonForm()

    return render(request, 'piston_form.html', {'form': form})